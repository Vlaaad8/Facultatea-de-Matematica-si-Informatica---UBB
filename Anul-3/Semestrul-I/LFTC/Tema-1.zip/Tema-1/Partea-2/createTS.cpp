#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>

using namespace std;

ifstream inA("atoms.txt");
ofstream outID("TS-ID.txt");
ofstream outCT("TS-CT.txt");


void generateTS(vector<string> &toSort) {

    map<string,int> tsCT;
    map<string,int> tsID;

    if (!inA.is_open()) {
        cout<<"Error opening input file"<<endl;
        exit(1);
    }
    if (!outID.is_open()) {
        cout<<"Error opening output-ID file"<<endl;
        exit(1);
    }
    if (!outCT.is_open()) {
        cout<<"Error opening output-CT file"<<endl;
        exit(1);
    }

    int positionCT=0;
    int positionID=0;
    for (string &line: toSort) {
        cout<<line<<endl;
        try {
            int a = stoi(line);
            cout<<a<<endl;
            positionCT++;
            tsCT.insert(pair(line,positionCT));
        }catch (invalid_argument &e) {
            try {
                float a = stof(line);
                cout<<a<<endl;
                positionCT++;
                tsCT.insert(pair(line,positionCT));
            }
            catch (invalid_argument &e) {
                positionID++;

                tsID.insert(pair(line,positionID));
            }
        }
    }
    for (pair<string,int> p : tsCT) {
        outCT<<p.first<<" "<<p.second<<endl;
    }
    for (pair<string,int> p : tsID) {
            outID<<p.first<<" "<<p.second<<endl;

    }
    inA.close();

}
#include <iostream>
#include <fstream>
#include <map>
#include <cctype>
#include <vector>
#include "createTS.h"
using namespace std;

ifstream in("program.txt");
ifstream inC("constantTable.txt");

ofstream out("atoms.txt");

map<string,int> generateReservedVocabulary() {
    map<string,int> res;
    if (!inC.is_open()) {
        cout<<"Error in opening Vocabulary file"<<endl;
        exit(1);
    }
    string line;
    while (getline(inC, line)) {
        int idx=line.find(' ');
        if (idx) {
            string word = line.substr(0, idx);
            int index = stoi(line.substr(idx + 1));
            res.insert(make_pair(word, index));
        }
    }
    return res;
}

int main() {
    vector<string> toSort;
    map<string,int> res = generateReservedVocabulary();
    if (!in.is_open()) {
        cout << "Error in opening input file" << endl;
        return 0;
    }

    if (!out.is_open()) {
        cout << "Error in opening output file" << endl;
        return 0;
    }
    out<<"Atom"<<" "<<"Cod Atom"<<"Cod in TS"<<endl;
    string line;
    while (getline(in, line)) {
        string tmp="";
        for (char c: line) {
            if (!isalpha(c) && !isdigit(c)) {
                if (res.contains(tmp)) {
                    out << tmp <<" "<< res[tmp]<< endl;
                }
                else if (tmp!="" and tmp!=" "){
                    toSort.push_back(tmp);
                    out<< tmp<<" -"<<endl;
                }
                if (res.contains(string(1,c))) {

                    out <<c <<" "<<res[string(1,c)]<< endl;
                }
                else if (c!=' '){
                    cout<<"Am adaugat 2"<<" "<<c<<endl;
                    toSort.push_back(string(1,c));
                    out << c<<" -"<<endl;;
                }
            tmp="";
            }
            else {
                tmp+=c;
            }
        }

    }
    generateTS(toSort);
    in.close();
    out.close();
}




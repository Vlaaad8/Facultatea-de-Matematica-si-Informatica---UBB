package org.example.demo.views;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import org.example.demo.domain.TrainStation;
import org.example.demo.service.ServiceCity;
import org.example.demo.service.ServiceTrainStation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MenuView {
    public static float PRICE_PER_STATION = 10;
    public CheckBox directBox;
    public ComboBox fromBox;
    public ComboBox toBox;
    public Button searchButton;
    public TableView tableView;
    public TableColumn<String, String> nameColumn;
    ObservableList<String> model = FXCollections.observableArrayList();
    private boolean flagOne = false;
    private boolean flagTwo = false;
    private ServiceCity serviceCity;
    private ServiceTrainStation serviceTrainStation;

    public void initialize() {
        nameColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue()));
    }

    public void setService(ServiceCity serviceCity, ServiceTrainStation serviceTrainStation) {
        this.serviceCity = serviceCity;
        this.serviceTrainStation = serviceTrainStation;
        initMain();
    }

    public void initMain() {
        ObservableList<String> toDestinations = FXCollections.observableArrayList();
        Iterable<String> destinations = serviceCity.destinations();
        List<String> d = StreamSupport.stream(destinations.spliterator(), false)
                .collect(Collectors.toList());
        toDestinations.setAll(d);
        toBox.setItems(toDestinations);
        if (!flagOne) {
            toBox.setValue(toDestinations.get(0));
            flagOne = true;
        }

        fromBox.setItems(toDestinations);
        if (!flagTwo) {
            fromBox.setValue(toDestinations.get(0));
            flagTwo = true;
        }
    }


    public void handleSearch(ActionEvent actionEvent) throws SQLException {
        if (directBox.isSelected() && toBox.getValue() != null && fromBox.getValue() != null) {

            List<String> rout = serviceTrainStation.findDirectRoutes(fromBox.getValue().toString(), toBox.getValue().toString(), PRICE_PER_STATION);
            List<String> d = StreamSupport.stream(rout.spliterator(), false)
                    .collect(Collectors.toList());
            model.setAll(d);
            tableView.setItems(model);

        }
        else{
            String route=serviceTrainStation.formatRoute(fromBox.getValue().toString(),toBox.getValue().toString(),PRICE_PER_STATION);
            model.setAll(route);
            tableView.setItems(model);

        }
    }
}


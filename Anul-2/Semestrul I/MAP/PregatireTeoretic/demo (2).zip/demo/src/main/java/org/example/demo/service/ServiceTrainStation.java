package org.example.demo.service;

import org.example.demo.domain.TrainStation;
import org.example.demo.repository.RepositoryCity;
import org.example.demo.repository.RepositoryTrainStation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;

public class ServiceTrainStation {
    private RepositoryTrainStation repoTrainStation;
    private RepositoryCity repoCity;

    public ServiceTrainStation(RepositoryTrainStation repoTrainStation,RepositoryCity repoCity) {
        this.repoTrainStation = repoTrainStation;
        this.repoCity = repoCity;

    }

    public Iterable<TrainStation> findAll() {
        try {
            return repoTrainStation.findAll();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<String> findDirectRoutes(String from, String to,float pricePerStation) throws SQLException {
        boolean found = false;
        List<String> routes = new ArrayList<>();

        for (TrainStation ts : repoTrainStation.findAll()) {
            String dep = ts.getDepartureCity();
            String dest = ts.getArrivalCity();

            if (dep.equals(from) && dest.equals(to)) {
                found = true;
               routes.add(dep + " --"+ts.getId()+"-->" + dest + " Total Price: "+ pricePerStation*2);
            }
        }

        if (!found) {
           routes.add("There are no available routes");
        }
        return routes;
    }

    public List<String> routeGraph2(String from, String to) throws SQLException {

        Graph<String, DefaultEdge> graph = new SimpleGraph<>(DefaultEdge.class);

        repoCity.findAll().forEach(user -> graph.addVertex(user.getCityName()));

        for(TrainStation ts : repoTrainStation.findAll()) {
            if(!ts.getDepartureCity().equals(from) && !ts.getArrivalCity().equals(to)) {
                graph.addEdge(ts.getDepartureCity(), ts.getArrivalCity());
            }
        }
        DijkstraShortestPath<String, DefaultEdge> dijkstraShortestPath = new DijkstraShortestPath<>(graph);
        List<String> shortestPath;

        try {
            shortestPath = dijkstraShortestPath.getPath(from, to).getVertexList();
        } catch (NullPointerException e) {
            throw new IllegalArgumentException("No route exists between " + from + " and " + to);
        }

        return shortestPath;
    }

    public String findIDByStations(String from,String to) {
        try {
            for(TrainStation trainStation: repoTrainStation.findAll()){
                if(trainStation.getDepartureCity().equals(from) && trainStation.getArrivalCity().equals(to)) {
                    return trainStation.getId();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public String formatRoute(String from,String to,float price) throws SQLException {
        List<String> stations=routeGraph(to,from);
        System.out.println("NUMAR DE STATII" + stations.size());
        StringBuilder route= new StringBuilder();
        for(int i=0;i<stations.size()-1;i++) {
            route.append(stations.get(i)).append("--").append(findIDByStations(stations.get(i),stations.get(i+1))).append("-->");
        }
        route.append(stations.get(stations.size()-1)).append(" Total Price: "+ price*stations.size());
        return route.toString();
    }

    public List<String> routeGraph(String to, String from) throws SQLException {

        Graph<String, DefaultEdge> graph = new SimpleGraph<>(DefaultEdge.class);


        repoCity.findAll().forEach(user -> graph.addVertex(user.getCityName()));


        repoTrainStation.findAll()
                .forEach(trainRoute -> graph
                        .addEdge(trainRoute.getDepartureCity(), trainRoute.getArrivalCity()));

        // Use Dijkstra's algorithm to find the shortest path between 'from' and 'to'
        DijkstraShortestPath<String, DefaultEdge> dijkstraShortestPath = new DijkstraShortestPath<>(graph);
        List<String> shortestPath;

        try {
            // Find and return the shortest path
            shortestPath = dijkstraShortestPath.getPath(from, to).getVertexList();
        } catch (NullPointerException e) {
            // Handle the case where no path exists
            throw new IllegalArgumentException("No route exists between " + from + " and " + to);
        }

        return shortestPath;
    }


}

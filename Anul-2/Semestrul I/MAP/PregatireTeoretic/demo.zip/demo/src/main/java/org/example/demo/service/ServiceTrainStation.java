package org.example.demo.service;

import org.example.demo.domain.TrainStation;
import org.example.demo.repository.RepositoryCity;
import org.example.demo.repository.RepositoryTrainStation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.jgrapht.Graph;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;

public class ServiceTrainStation {
    private RepositoryTrainStation repoTrainStation;
    private RepositoryCity repoCity;

    public ServiceTrainStation(RepositoryTrainStation repoTrainStation,RepositoryCity repoCity) {
        this.repoTrainStation = repoTrainStation;
        this.repoCity = repoCity;

    }

    public Iterable<TrainStation> findAll() {
        try {
            return repoTrainStation.findAll();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<String> routeGraph(String to, String from) throws SQLException {

        Graph<String, DefaultEdge> graph = new SimpleGraph<>(DefaultEdge.class);


        repoCity.findAll().forEach(user -> graph.addVertex(user.getCityName()));


        repoTrainStation.findAll()
                .forEach(trainRoute -> graph
                        .addEdge(trainRoute.getDepartureCity(), trainRoute.getArrivalCity()));

        // Use Dijkstra's algorithm to find the shortest path between 'from' and 'to'
        DijkstraShortestPath<String, DefaultEdge> dijkstraShortestPath = new DijkstraShortestPath<>(graph);
        List<String> shortestPath;

        try {
            // Find and return the shortest path
            shortestPath = dijkstraShortestPath.getPath(from, to).getVertexList();
        } catch (NullPointerException e) {
            // Handle the case where no path exists
            throw new IllegalArgumentException("No route exists between " + from + " and " + to);
        }

        return shortestPath;
    }

    public String formatRoute(String to,String from) throws SQLException {
        List<String> a=routeGraph(from,to);
        String route="";
        for(String m:a){
            route+=m+"---->";
        }
        return route;
    }



}

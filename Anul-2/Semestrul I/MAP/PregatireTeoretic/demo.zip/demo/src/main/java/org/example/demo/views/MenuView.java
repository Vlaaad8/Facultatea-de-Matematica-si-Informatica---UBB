package org.example.demo.views;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.demo.service.ServiceCity;
import org.example.demo.service.ServiceTrainStation;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MenuView {
    public CheckBox directBox;
    public ComboBox fromBox;
    public ComboBox toBox;
    public Button searchButton;
    public TableView tableView;
    public TableColumn<String,String> nameColumn;
    private boolean flagOne=false;
    private boolean flagTwo=false;

    private ServiceCity serviceCity;
    private ServiceTrainStation serviceTrainStation;
    ObservableList<String> model = FXCollections.observableArrayList();

    public void initialize() {
        nameColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue()));
    }
    public void setService(ServiceCity serviceCity,ServiceTrainStation serviceTrainStation) {
        this.serviceCity = serviceCity;
        this.serviceTrainStation = serviceTrainStation;
        initMain();
    }

    public void initMain() {
        ObservableList<String> toDestinations = FXCollections.observableArrayList();
        Iterable<String> destinations = serviceCity.destinations();
        List<String> d = StreamSupport.stream(destinations.spliterator(), false)
                .collect(Collectors.toList());
        toDestinations.setAll(d);
        toBox.setItems(toDestinations);
        if (!flagOne) {
            toBox.setValue(toDestinations.get(0));
            flagOne = true;
        }

        fromBox.setItems(toDestinations);
        if (!flagTwo) {
            fromBox.setValue(toDestinations.get(0));
            flagTwo = true;
        }
    }


    public void handleSearch(ActionEvent actionEvent) throws SQLException {
        if (toBox.getValue()!=null && fromBox.getValue()!=null) {

            String rout= serviceTrainStation.formatRoute(fromBox.getValue().toString(),toBox.getValue().toString());

            model.setAll(rout);
            tableView.setItems(model);

        }
    }
}


#ifndef TEMA_1_CREATETS_H
#define TEMA_1_CREATETS_H
#include <string>
#include <vector>

using namespace std;

void generateTS(vector<string> &toSort);


#endif //TEMA_1_CREATETS_H